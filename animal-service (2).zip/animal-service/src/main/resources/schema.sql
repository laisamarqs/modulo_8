CREATE TABLE animal (
  id INT NOT NULL,
   nome_provisorio VARCHAR(255) NOT NULL,
   idade_estimada INT NOT NULL,
   `ra?a` VARCHAR(255) NOT NULL,
   data_entrada date NOT NULL,
   `dataado?ao` date NULL,
   condicoes_chegada VARCHAR(255) NOT NULL,
   nome_recebedor VARCHAR(255) NOT NULL,
   data_obito date NULL,
   porte VARCHAR(255) NOT NULL,
   CONSTRAINT pk_animal PRIMARY KEY (id)
);