package br.com.ebac.animalservice.controllers;

import br.com.ebac.animalservice.entidades.Animal;
import br.com.ebac.animalservice.repositorios.AnimalRepository;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/animais")
public class AnimalController {
    private AnimalRepository repository;

    public AnimalController(AnimalRepository repository) {
        this.repository= repository;
    }

    @GetMapping
    private List<Animal> findAll() {
        return repository.findAll();
    }

    @PostMapping
    private Animal create(@RequestBody Animal animal) {
    return repository.save(animal);
    }

    @GetMapping("/not-adpoted")
    private List<Animal> findNotAdpoted () {
        return repository.findNotAdopted();
    }

    @GetMapping("/not-adpoted")
    private List<Animal> findAdpoted () {
        return repository.findAdopted();
    }
}
