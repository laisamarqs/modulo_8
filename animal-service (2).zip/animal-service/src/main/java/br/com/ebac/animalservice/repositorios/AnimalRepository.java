package br.com.ebac.animalservice.repositorios;

import br.com.ebac.animalservice.entidades.Animal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface  AnimalRepository extends JpaRepository<Animal, Integer> {
    Animal save();

    @Query("Select a from Animal a WHERE a.dataAdocao IS NULL ORDER BY a.dataEntrada DESC")
    List<Animal> findNotAdopted();

    @Query(" Select a from Animal a WHERE a.dataAdocao IS NOT NULL")
    List<Animal> findAdopted();
}
