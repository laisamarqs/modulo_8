package br.com.ebac.animalservice.entidades;

import jakarta.persistence.*;

import java.sql.Date;

@Entity

public class Animal {



    @Id

    @GeneratedValue ( strategy = GenerationType.IDENTITY )

    @Column ( name = "id", nullable = false )
    private Integer id;



    public Integer getId() {
     return id;

    }
    @Column (nullable = false)
    private String nomeProvisorio;

    @Column (nullable = false)
    private Integer idadeEstimada;

    @Column (nullable = false)
    private String raça;

    @Column (nullable = false)
    private Date dataEntrada;

    @Column
    private Date dataadoçao;

    @Column (nullable = false)
    private String condicoesChegada;

    @Column (nullable = false)
    private String nomeRecebedor;

    @Column
    private Date dataObito;

    @Column (nullable = false)
    private String porte;

    public String getNomeProvisorio() {
        return nomeProvisorio;
    }

    public void setNomeProvisorio(String nomeProvisorio) {
        this.nomeProvisorio = nomeProvisorio;
    }

    public Integer getIdadeEstimada() {
        return idadeEstimada;
    }

    public void setIdadeEstimada(Integer idadeEstimada) {
        this.idadeEstimada = idadeEstimada;
    }

    public String getRaça() {
        return raça;
    }

    public void setRaça(String raça) {
        this.raça = raça;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public Date getDataadoçao() {
        return dataadoçao;
    }

    public void setDataadoçao(Date dataadoçao) {
        this.dataadoçao = dataadoçao;
    }

    public String getCondicoesChegada() {
        return condicoesChegada;
    }

    public void setCondicoesChegada(String condicoesChegada) {
        this.condicoesChegada = condicoesChegada;
    }

    public String getNomeRecebedor() {
        return nomeRecebedor;
    }

    public void setNomeRecebedor(String nomeRecebedor) {
        this.nomeRecebedor = nomeRecebedor;
    }

    public Date getDataObito() {
        return dataObito;
    }

    public void setDataObito(Date dataObito) {
        this.dataObito = dataObito;
    }

    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        this.porte = porte;
    }
}

